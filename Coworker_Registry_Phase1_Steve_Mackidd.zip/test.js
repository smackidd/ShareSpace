// let property = [];
// let newPropertyID = 0;
// let propertyTemp = ["bow", "101, 500 1st St SE", "beltline", "2400"];
// let workspaceTemp = ["conference", "6", false, "2020-03-01", "one week"];

// property.push(newPropertyID);
// property.push(propertyTemp);
// property.push(workspaceTemp);
// console.log(property[2].length);

// var currentUser = {};
// let workspacesAll;
// if (localStorage.getItem('workspaces')){
//     workspacesAll = JSON.parse(localStorage.getItem('workspaces'));
// }

// console.log("workspacesAll: ", workspacesAll);

//  console.log(workspacesAll.length);

// for (let i = 1; i < workspacesAll[0].length; i++) {
//     console.log("hello");
//     console.log(workspacesAll[0][i].property[1].propertyName);


var fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits.splice(1,2));
console.log(fruits);